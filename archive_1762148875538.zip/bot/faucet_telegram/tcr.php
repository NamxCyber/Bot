<?php

/*
if (!defined('title') || title == "") {
    define("title", "tronpayu");
    require "../../modul/class.php";
}
*/

const
versi = "0.0.1",
host = "https://appkviz.com/",
refflink = "https://t.me/taskcryptorewards_bot/taskcryptorewards?startapp=U3BTEGNX";

class Bot {
	function __construct(){
		Display::Ban(title, versi);
		$this->config = "data/".title."/data.json";
		if(!file_exists("data/".title)){
			system("mkdir ".title);
			if(PHP_OS_FAMILY == "Windows"){system("move ".title." data");}else{system("mv ".title." data");}
			print Display::Sukses("Berhasil membuat folder ".title);
		}
		cookie:
		Display::Cetak("Register",refflink);
		Display::Line();
		
		
		menu:
		Display::Menu(1, "Add Account");
		Display::Menu(2, "Run bot");
		print Display::Isi("Nomor");
		$pil = readline();
		Display::Line();
		
		if($pil == 1)$this->input_data_user();
		if($pil == 2)$this->Dashboard();
	}
	private function input_data_user()
	{
		while(true){
			$array = [];
			$config = [];
			if(file_exists($this->config)){
				$config = json_decode(file_get_contents($this->config),1);
			}
			print k."Total account: ". count($config)."\n";
			Display::Line();
			print Display::Title("Add account");
			print Display::Isi("Authorization")."\t";
			$auth = readline();
			print Display::Isi("User-Agent")."\t";
			$user_agent = readline();
			
			// if(isset($auth) && isset($user_agent)){
			// 	//Cek
			// 	$this->authorization = $auth;
			// 	$this->uagent = $user_agent;
			// 	// $dashboard = $this->Dashboard();
			// 	// if($dashboard['Username']){
			// 	// 	// $username = $dashboard['Username'];
			// 	// 	// foreach($config as $con){
			// 	// 	// 	if($con['username'] == $username || 
			// 	// 	// 	$con['Authorization'] == $auth
			// 	// 	// 	){
			// 	// 	// 		print Display::Error("The account has been saved previously\n");
			// 	// 	// 		goto ngent;
			// 	// 	// 	}
			// 	// 	// }
					
			// 	// 	// $array = [['username'=> $username, 'authorization' => $auth, 'user-agent'=>$user_agent]];
			// 	// 	// Display::Cetak("Username", $dashboard['Username']);
					
			// 	// }
                
			// }
            $array = [['authorization' => $auth, 'user-agent'=>$user_agent]];
            $dataPost = array_merge($config, $array);
			file_put_contents($this->config, json_encode($dataPost,JSON_PRETTY_PRINT));
			print Display::Sukses("Account have been saved");
			Display::Line();
			ngent:
			print Display::Sukses("Press enter to add another account");
			print Display::Error("Press CTRL + C to stop adding accounts\n");
			readline();
		}
	}
	private function headers($data = 0){
        $h[] = "Host: ".parse_url(host)['host'];
		    $h[] = "User-Agent: ".$this->uagent;
        $h[] = "Accept: */*";
        $h[] = "Referer: https://appkviz.com/app/";
        $h[] = "Content-Type: application/json";
		    $h[] = "Authorization: ".$this->authorization;
        $h[] = "Platform: weba";
        $h[] = "Origin: https://appkviz.com";
        $h[] = "Priority: u=1, i";
		    $h[] = "Connection: Keep-Alive";
		    $h[] = 'sec-ch-ua: "Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"';
		    $h[] = 'sec-ch-ua-platform: "Android"';
		    $h[] = 'sec-fetch-site: same-origin';
		    $h[] = 'sec-fetch-mode: cors';
		    $h[] = 'sec-fetch-dest: empty';
		    $h[] = 'sec-fetch-storage-access: active';
		return $h;
	}
	private function Dashboard(){
		 $r = Requests::Curl(host."/api/user/auth/telegram",$this->headers(),['platform:weba'])[1];
        print_r($r);
		// $user = json_decode("username");
		// $balance = "balance";
		// return ["Username" => $user, "Balance" => $balance];
	}
	// private function run_bot(){
	// 	if(!file_exists($this->config) || count(json_decode(file_get_contents($this->config),1)) < 1){
	// 		print Display::Error("account not detected, add account first\n");
	// 		Display::Line();
	// 		return;
	// 	}
	// 	while(true){
	// 		$list_akun = json_decode(file_get_contents($this->config),1);
	// 		foreach($list_akun as $akun){
	// 			$this->cookie = $akun['cookie'];
	// 			$this->uagent = $akun['user-agent'];
	// 			$r = json_decode(Requests::get(host."/home/claim",$this->headers())[1],1);
	// 			if($r['status']){
	// 				$dashboard = $this->Dashboard();
	// 				Display::Cetak("Username", $dashboard['Username']);
	// 				Display::Cetak("Payout", $r['payout']);
	// 				Display::Cetak("Balance", $dashboard['Balance']);
	// 				Display::Line();
	// 			}
	// 		}
	// 		Functions::Tmr(3600);
	// 	}
	// }
}

new Bot();