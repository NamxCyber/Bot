<?php

const
versi = "0.0.1",
host = "https://claimcoin.in/";
class Bot {
	public function __construct(){
		Display::Ban(title, versi);
		cookie:
		Display::Line();
		$this->cookie = Functions::setConfig("cookie");
		$this->uagent = Functions::setConfig("user_agent");
		$this->scrap = new HtmlScrap();
		// $this->captcha = new Captcha();
		
		Display::Ban(title, versi);
			
		$r = $this->Dashboard();
		// if(!$r['username']){
		// 	Functions::removeConfig("cookie");
		// 	print Display::Error("Cookie Expired\n");
		// 	Display::Line();
		// 	goto cookie;
		// }
		
		Display::Cetak("Username",$r['username']);
		Display::Cetak("Balance",$r['balance']);
		// Display::Cetak("Apikey",$this->captcha->getBalance());
		Display::Line();
		// if($this->ptc()){
		// 	Functions::removeConfig("cookie");
		// 	print Display::Error("Cookie Expired\n");
		// 	Display::Line();
		// 	goto cookie;
		// }
		if($this->faucet()){
			Functions::removeConfig("cookie");
			print Display::Error("Cookie Expired\n");
			Display::Line();
			goto cookie;
		}
	}
	
	public function headers($xml=0){
		$h[] = "Host: ".parse_url(host)['host'];
		if($xml)$h[] = "x-requested-with: XMLHttpRequest";
		$h[] = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
		$h[] = "User-Agent: ".$this->uagent;
		$h[] = "Cookie: ".$this->cookie;
		return $h;
	}

	public function Dashboard(){
		das:
		$r = Requests::get(host."/dashboard",$this->headers())[1];
		$scrap = $this->scrap->Result($r);
		if($scrap['locked']){
			$tmr = explode('">',explode('<span class="counter" wait="',$r)[1])[0];
			if($tmr){
				Functions::Tmr($tmr+5);
				goto das;
			}
		}
		$bal = explode('</h2>',explode('<h2 class="f-w-600">', $r)[1])[0];
		$username = explode('</span>',explode('<span class="d-none d-xl-inline-block ml-1" key="t-henry">', $r)[1])[0];//iewilmaestro
		return ["username"=>$username, "balance"=>$bal];
	}
	private function faucet(){
		while(true){
			$r = Requests::get(host."faucet",$this->headers())[1];
			$tmr = 6;
			if(preg_match('/Daily limit reached/', $r)){//, see you tomorrow
		  	print Display::Error("Daily limit reached, claim from Shortlink Wall to earn energy".n);
				break;
			}
			$scrap = $this->scrap->Result($r);
            $data = $scrap['input'];
			if($scrap['input']['_iconcaptcha-token']){
				$icon = FreeCaptcha::iconBypass($scrap['input']['_iconcaptcha-token'], $this->headers());
				if(!$icon)continue;
				$data = array_merge($data, $icon);
			}else{
				print Display::Error("Captcha Blom Ready!\n"); 
				continue;
			}
			$data = http_build_query($data);
			$r = Requests::post(host."faucet/verify",$this->headers(), $data)[1];
			preg_match("/Swal\.fire\('([^']*)', '([^']*)', '([^']*)'\)/", $r, $matches);
			if($matches[1] == 'Good job!'){
			//	Display::Cetak('Limit', $scrap['faucet'][0][0]);
				print Display::Sukses($matches[2]);
				$r = $this->Dashboard();
				Display::Cetak("Balance",$r['balance']);
				// Display::Cetak("Apikey",$this->captcha->getBalance());
				Display::Line();
			}else{
				//print_r($r);exit;
				print Display::Error("no respon".n);
				Display::Line();
			}
			if($tmr){
				Functions::Tmr($tmr);
				continue;
			}
		}
	}


}new Bot();