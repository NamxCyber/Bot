<?php

const
versi = "0.0.1",
host = "https://mixfaucet.com/";
class Bot {
	public function __construct(){
		Display::Ban(title, versi);
		
		cookie:
		
		Display::Line();
		$this->cookie = Functions::setConfig("cookie");
		$this->uagent = Functions::setConfig("user_agent");
		$this->scrap = new HtmlScrap();
		$this->captcha = new Captcha();
		
		Display::Ban(title, versi);
			
		$r = $this->Dashboard();
        Display::Cetak("Username",$r['username']);
        Display::Cetak("Balance",$r['balance']);
		Display::Cetak("Apikey",$this->captcha->getBalance());
		Display::Line();
		if(!$r['username']){
			Functions::removeConfig("cookie");
			print Display::Error("Cookie Expired\n");
			Display::Line();
			goto cookie;
		}
       $r = $this->ptc();
        if($this->faucet()){
			Functions::removeConfig("cookie");
			goto cookie;
		}

    }
    private function headers($xml=0){
		$h[] = "Host: ".parse_url(host)['host'];
		if($xml)$h[] = "x-requested-with: XMLHttpRequest";
		$h[] = "User-Agent: ".$this->uagent;
		$h[] = "Cookie: ".$this->cookie;
		return $h;
	}
	public function Firewall(){
		while(1){
			$r = Requests::get(host."firewall",$this->headers())[1];
			$scrap = $this->scrap->Result($r);
			$data = $scrap['input'];
			
			if($scrap['captcha']['g-recaptcha']){
				$data['captcha'] = "recaptchav2";
				$cap = $this->captcha->RecaptchaV2($scrap['captcha']['g-recaptcha'], host."firewall");
				if(!$cap)continue;
				$data['g-recaptcha-response'] = $cap;
			}else{
				print Display::Error("Sitekey Error\n"); 
				continue;
			}
			
			$r = Requests::post(host."firewall/verify",$this->headers(), http_build_query($data))[1];
			if(preg_match('/Invalid Captcha/',$r))continue;
			Display::Cetak("Firewall","Bypassed");
			Display::Line();
			return;
		}
	}
	public function Dashboard(){
		das:
		$r = Requests::get(host."dashboard",$this->headers())[1];
		$scrap = $this->scrap->Result($r);
		if($scrap['locked']){
			$tmr = explode('">',explode('<span class="counter" wait="',$r)[1])[0];
			if($tmr){
				Functions::Tmr($tmr+5);
				goto das;
			}
		}
		if($scrap['firewall']){
			print Display::Error("Firewall Detect\n");
			$this->Firewall();
			continue;
		}
		$bal = explode('</h5>',explode('<h5 class="mb-0 me-2">', $r)[1])[0];
		$username = explode('</div>',explode('<div class="fw-bold username-hover" style="color:#4a86ff;">', $r)[1])[0];//iewilmaestro
		return ["username"=>$username, "balance"=>$bal];
	}
    private function ptc(){
        $r = Requests::get(host."ptc",$this->headers())[1];
      	if($scrap['firewall']){
				print Display::Error("Firewall Detect\n");
				$this->Firewall();
				continue;
			}
        $id = explode("'",explode('/view/',$r)[1])[0];
        
		if(!$id){
			print Display::Error("Ads are finished\n");
			Display::Line();
			return;
		}
		$r = Requests::get(host."ptc/view/".$id,$this->headers())[1];
        $tmr = explode(';',explode('var timer = ', $r)[1])[0];
        if($tmr){
			Functions::Tmr($tmr);
		}
        $scrap = $this->scrap->Result($r);
		$data = $scrap['input'];
        $cap = $scrap['captcha']['g-recaptcha'];
		$data['captcha'] = "recaptchav2";
		$cap = $this->captcha->RecaptchaV2($cap, host."ptc/view/".$id);
		$data['g-recaptcha-response']=$cap;
        $data = http_build_query($data);
		$r = Requests::post(host."ptc/verify/".$id,$this->headers(), $data)[1];
        preg_match("/Swal\.fire\('([^']*)', '([^']*)', '([^']*)'\)/", $r, $matches);
		if($matches[1] == 'Good job!'){
		//	Display::Cetak('Limit', $scrap['faucet'][0][0]);
			print Display::Sukses($matches[2]);
			$r = $this->Dashboard();
			Display::Cetak("Balance",$r['balance']);
			// Display::Cetak("Apikey",$this->captcha->getBalance());
			Display::Line();
		}else{
			//print_r($r);exit;
			print Display::Error("no respon".n);
			Display::Line();
		}
    }
	private function faucet(){
		while(true){
		  again:
			$r = Requests::get(host."faucet",$this->headers())[1];
			$scrap = $this->scrap->Result($r);
			if($scrap['locked']){
				print Display::Error("Account Locked\n");
				$tmr = explode('">',explode('<span class="counter" wait="',$r)[1])[0];
				if($tmr){
					Functions::Tmr($tmr+5);
					continue;
				}
			}
			if($scrap['firewall']){
				print Display::Error("Firewall Detect\n");
				$this->Firewall();
				continue;
			}
			if($scrap['cloudflare']){
				print Display::Error(host."faucet".n);
				print Display::Error("Cloudflare Detect\n");
				Display::Line();
				return 1;
			}
      $data = $scrap['input'];
			$cekATB = explode('rel=\"',$r);
			if(isset($cekATB[1])){
				$antibot = $this->captcha->AntiBot($r);
				if(!$antibot)continue;
				$data['antibotlinks'] = str_replace("+"," ",$antibot);
			}
			if($scrap['captcha']['cf-turnstile']){
				$data['captcha'] = "turnstile";
				// $cap = $this->captcha->Turnstile($scrap['captcha']['cf-turnstile'], host."faucet");
				$data['cf-turnstile-response']="";
				// $data['g-recaptcha-response']=$cap;
				// if(!$cap)continue;
			}else{
				print Display::Error("Sitekey Error\n"); 
				continue;
			}
			sleep(5);
			$data = http_build_query($data);
			$r = Requests::post(host."faucet/verify",$this->headers(), $data)[1];
			$wr = explode('</div>', explode('<i class="fas fa-exclamation-circle"></i> ',$r)[1])[0];//Invalid Anti-Bot Links
			preg_match("/Swal\.fire\('([^']*)', '([^']*)', '([^']*)'\)/", $r, $matches);
			if($matches[1] == 'Good job!'){
			//	Display::Cetak('Limit', $scrap['faucet'][0][0]);
				print Display::Sukses($matches[2]);
				$r = $this->Dashboard();
				Display::Cetak("Balance",$r['balance']);
				Display::Cetak("Apikey",$this->captcha->getBalance());
				Display::Line();
			}elseif($wr){
				print Display::Error($wr.n);
				Display::Line();
				goto again;
			}else{
				//print_r($r);exit;
				print Display::Error("no respon".n);
				Display::Line();
			}
			Functions::tmr(300);
		}
	}

}new Bot();