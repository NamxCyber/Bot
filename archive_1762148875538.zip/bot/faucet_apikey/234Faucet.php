<?php

const
versi = "0.0.1",
host = "https://faucet234.shop/",
refflink = "https://faucet234.shop?ref=3dOSqNRF35GI";
class Bot {
	public function __construct(){
		Display::Ban(title, versi);
		
		cookie:
		
		Display::Line();
		$this->cookie = Functions::setConfig("cookie");
		$this->uagent = Functions::setConfig("user_agent");
		$this->scrap = new HtmlScrap();
		$this->captcha = new Captcha();
		
		Display::Ban(title, versi);
			
		$r = $this->Dashboard();
        // Display::Cetak("Username",$r['username']);
        Display::Cetak("Balance",$r['balance']);
		Display::Cetak("Apikey",$this->captcha->getBalance());
		Display::Line();
		if(!$r['balance']){
			Functions::removeConfig("cookie");
			print Display::Error("Cookie Expired\n");
			Display::Line();
			goto cookie;
		}
        $r = $this->faucet();
    }
    public function headers($xml=0){
		$h[] = "Host: ".parse_url(host)['host'];
		if($xml)$h[] = "x-requested-with: XMLHttpRequest";
		$h[] = "User-Agent: ".$this->uagent;
		$h[] = "Cookie: ".$this->cookie;
		return $h;
	}
	
	public function Dashboard(){
		das:
		$r = Requests::get(host."home",$this->headers())[1];
		// $scrap = $this->scrap->Result($r);
		// if($scrap['locked']){
		// 	$tmr = explode('">',explode('<span class="counter" wait="',$r)[1])[0];
		// 	if($tmr){
		// 		Functions::Tmr($tmr+5);
		// 		goto das;
		// 	}
		// }
		$bal = explode('</span>',explode('<span class="strongText" id="myBalance">', $r)[1])[0];
		// $username = explode('</p>',explode('<p class="me-2">', $r)[1])[0];//iewilmaestro
		return ["balance"=>$bal];
	}
    private function faucet(){
		while(true){
			$r = Requests::get(host."faucet",$this->headers())[1];
			$scrap = $this->scrap->Result($r);
            $data = $scrap['input'];
			$tmr = 60;
			preg_match('/(\d{1,})\/(\d{1,})/',$r,$limit);
			if($limit[2]){
				$sisa = $limit[1];
				$limit = $limit[2];
			}
			if($sisa >= 1000){
				print Display::Error("Limit Claim Faucet\n");
				Display::Line();
				return;
			}
			
			if($scrap['captcha']['g-recaptcha']){
				$cap = $this->captcha->RecaptchaV2($scrap['captcha']['g-recaptcha'], host."faucet");
				$data['g-recaptcha-response']=$cap;
				if(!$cap)continue;
			}else{
				print Display::Error("Sitekey Error\n"); 
				continue;
			}
			$data = http_build_query($data);
			$r = Requests::post(host."faucet/claim",$this->headers(), $data)[1];
			if ($sisa < 1000){
				print Display::Sukses("+50 Zero");
				Display::Cetak("Sisa",$sisa."/".$limit);
				$r = $this->Dashboard();
				Display::Cetak("Balance",$r['balance']);
			  Display::Cetak("Apikey",$this->captcha->getBalance());
				Display::Line();
			}else{
				Display::Cetak("Today Claim",$sisa."/".$limit);
				print Display::Error("Failed Claim".n);
				Display::Cetak("Balance",$r['balance']);
				Display::Line();
			}
			if($tmr){Functions::tmr($tmr);}
		}
	}

}
new Bot();